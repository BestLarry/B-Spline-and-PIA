#include <iostream>
#include <functional>
#include <imgproc/imgproc.hpp>
#include <highgui/highgui.hpp>
#include "Vec.h"
#include "BSpline.h"

using namespace cv;
using namespace std;

typedef function<Vec2D(double)> Curve;

Point2d v2p(const Vec2D& v)
{
    return Point2d(v.x, v.y);
}

void DrawCurve(Mat img, function<Vec2D(double)> curve, const Scalar& color, double begin, double end, 
    double interval = 0.01, int thickness = 1, int lineType = LINE_8, int shift = 0)
{
    Point2d old_point = v2p(curve(begin));
    for (double i = begin + interval; i < end - interval; i += interval)
    {
        Point2d new_point = v2p(curve(i + interval));
        line(img, old_point, new_point, color, thickness, lineType, shift);
        old_point = new_point;
    }
}

int main()
{
    Mat img = Mat::zeros(Size(800, 600), CV_8UC3);
    img.setTo(255);              // ������ĻΪ��ɫ

    vector<Vec2D> controls = { {200,200},{300,300},{400,200} };
    for (auto& v : controls)
    {
        circle(img, v2p(v), 2, Scalar(0, 0, 255), -1);
    }
    vector<double> knots = { 0, 0.2, 0.4, 0.6, 0.8, 1.0 };
    size_t degree = 2;
    BSpline a(controls, knots, degree);
    DrawCurve(img, Curve(a), Scalar(0, 0, 0), 0, 1, 0.01);

    imshow("����", img);
    waitKey();

    return 0;
}